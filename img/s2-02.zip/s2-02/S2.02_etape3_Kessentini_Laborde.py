# -*- coding: utf-8 -*-
"""
SAE 2.02 EXPLORATION ALGORITHMIQUE D'UN PROBLEME
Created on Thu Mar 30 09:39:11 2023
@author: Kessentini_Nour & Laborde_Romain
Etape 3 : 
"""

""" 
A. Lecture des données externes
"""

from math import *
import pandas as pd
import numpy as np
import os 
import sys
import time
#sys.path.append(os.path.abspath("F:\courBut\semestre2\s202\etape3"))
sys.path.append(os.path.abspath('F:\BUT\semestre2\sae\romain'))
#os.chdir('F:\courBut\semestre2\s202\etape3')
os.chdir('F:\BUT\semestre2\sae\romain')
os.getcwd()

from graphics import *
from algorithme import *

# Création dataframe "notre_liste_points" pour calculer l'heuristique
notre_liste_points=pd.read_table('notreListePoints.csv', sep=',', index_col='Unnamed: 0',
                         encoding='latin_1')

#notre_liste_succ=pd.read_table('listeSucc.csv',sep=',',index_col='Unnamed: 0',encoding='latin_1')

# Transformation dataframe "notre_liste_points" en dictionnaire
# préparation des données pour calculer notre heuristique
notreListePoints = {}
for index,row in notre_liste_points.iterrows():
    notreListePoints[row[1]] = row[0].split(',')
for key in notreListePoints:
    for i in range(len(notreListePoints[key])):
        notreListePoints[key][i] = float(notreListePoints[key][i])


# Importation de notre matrice de poids obtenue à l'étape 1
notre_mat_poids=pd.read_table('notreMatricePoids.csv', sep=',', index_col='Unnamed: 0',
                              encoding='latin_1')

# Transformation du dataframe "notre_mat_poids" en liste de liste
notreMatricePoids=notre_mat_poids.values.tolist()

# Permet d'associer le nom du sommet (point) à son indice dans matricePoids
def nom_sommet(indice):
    return "S_" + str(indice+1)
# Permet d'associer l'indice du sommet (point) à son nom, nompoint
def indice_sommet(nompoint):
    return int(nompoint.split("_")[1])-1


def listSucc(poids,sommet):
    """
    Permet de retourner la liste de
    successeurs de "sommet" dans la
    matrice des poids.

    Parameters
    ----------
    poids : mMtrice des poids
    sommet : Sommet de départ

    Returns
    -------
    succ : La liste des successeurs de sommet
    """
    #Initialisation
    succ = []
    n = len(poids)
    for i in range(n):
        if poids[sommet][i] != float('inf'):
            succ.append(i)
    return succ

def plusCourtChemin(u,v,dist,pred):
    """
    Reconstitue le chemin entre le sommet "u"
    et le sommet "v" à l'aide de la liste des 
    prédécesseurs.
    
    Parameters
    ----------
    u : Indice du sommet d'arrivée
    v : Indice du sommet de départ
    dist : Liste des distances
    pred : Liste des prédécésseurs

    Returns
    -------
    chemin : La liste des sommets composant le plus 
             court chemin
    distance : La distance du plus court chemin
    """
    chemin=[nom_sommet(u),nom_sommet(v)]
    distance=dist[v]
    while pred[v] != u:
        v = pred[v]
        chemin.insert(1, nom_sommet(v))
    return (chemin,distance) 


"""
ALGORITHME A* --------------------------------------------------------------------------------------------
"""
#########################################################
# calcul de la  distance entre deux points A et B dont  #
# on connait la lattitude et la longitude               #
#########################################################
def distanceGPS(latA,latB,longA,longB):
    # Conversions des latitudes en radians
    ltA=latA/180*pi
    ltB=latB/180*pi
    loA=longA/180*pi
    loB=longB/180*pi
    # Rayon de la terre en mètres 
    RT = 6378137
    # angle en radians entre les 2 points
    S = acos(round(sin(ltA)*sin(ltB) + cos(ltA)*cos(ltB)*cos(abs(loB-loA)),14))
    # distance entre les 2 points, comptée sur un arc de grand cercle
    return S*RT

# Permet de calculer la distanceGPS (à vol d'oiseau) entre 
# deux sommets
def heuristique(som_A,som_B):
    return distanceGPS(notreListePoints[som_A][1], notreListePoints[som_B][1],
                       notreListePoints[som_A][0], notreListePoints[som_B][0])

# Extrait le sommet qui possède le plus petit coût
# soit sa distance "dist" + sa distanceGPS jusqu'à 
# l'arrivée
def extract_minH(list_som,dist,heu):
    n = len(list_som)
    val = float('inf')
    s = 0
    # Traitements
    for i in range(n):
        if dist[list_som[i]] + heu[list_som[i]] < val:
            val = dist[list_som[i]] + heu[list_som[i]]
            s = i
    return list_som.pop(s)

def aStar(window, list_point, poids, som_dep, som_arr):
    # Initialisation
    n = len(poids)
    
    dist = [float("inf")]*n
    pred = {}
    s = indice_sommet(som_dep)
    L = [i for i in range(n)]
    dist[s] = 0
    pred[s] = None
    heu = []
    V = []
    
    # Calcul des heuristiques
    for key in notreListePoints:
        heu.append(heuristique(key, som_arr))
        
    startTime = time.time() # Déclenchement du timer
    while True:
        if L == []:
            break

        if indice_sommet(som_arr) in V:
            break
        # L'extraction se fait en tenant compte 
        # de l'heuristique des sommets
        s = extract_minH(L,dist,heu)
    
        sPoint = Point(list_point[nom_sommet(s)][0]+4, list_point[nom_sommet(s)][1]+4)
        for val in listSucc(poids,s):
            # On vérifie que le successeur n'a pas était
            # visité
            if val not in V:
                if dist[s] + poids[s][val] < dist[val]:
                    valPoint = Point(list_point[nom_sommet(val)][0]+4, list_point[nom_sommet(val)][1]+4)
                    dist[val] = dist[s] + poids[s][val]
                    pred[val] = s
                    line = Line(sPoint, valPoint)
                    line.setFill("orange")
                    line.setWidth(1.5)
                    line.draw(window)
                    time.sleep(0.05)
                
        V.append(s)       
                
    endTime = time.time() # Arrêt du timer
    
    resultChemin = plusCourtChemin(indice_sommet(som_dep), indice_sommet(som_arr), dist, pred)
    chemin = resultChemin[0]
    distance = resultChemin[1]
    print('Solution : \n - chemin : ' + str(chemin) + '\n - distance: ' + str(distance) + '\n - Temps exécution : ' + str(endTime - startTime))
    return chemin,distance

      
"""
Conversion coordonées GPS vers pixels --------------------------------------------------------------------
"""
minLong = float('inf')
minLat = float('inf')
maxLong = 0 
maxLat = 0


for key in notreListePoints:
    minLong = min(notreListePoints[key][0],minLong)
    minLat = min(notreListePoints[key][1], minLat)
    maxLong = max(notreListePoints[key][0],maxLong)
    maxLat = max(notreListePoints[key][1],maxLat)
        
        
deltaMaxMinLong = maxLong - minLong
deltaMaxMinLat = maxLat - minLat 

mapLatBottom = minLat;
mapLatBottomDegree = mapLatBottom * math.pi / 180

# Fonction de conversion utilisant la projection Mercator
def coordGpsToPixel2(long_x, lat_x):
    coord_x = ((long_x - minLong)*(892 / deltaMaxMinLong))
    
    lat = lat_x * math.pi / 180
    worldMapWidth = ((892 / deltaMaxMinLong) * 360) / (2 * math.pi)
    mapOffsetY = (worldMapWidth / 2 * math.log((1 + math.sin(mapLatBottomDegree)) / (1 - math.sin(mapLatBottomDegree))))
    coord_y = (892 - ((worldMapWidth / 2 * math.log((1 + math.sin(lat)) / (1 - math.sin(lat)))) - mapOffsetY))
    return coord_x,coord_y
    

# Notre fonction de conversion
def coordGpsToPixel(long_x,lat_x):
    coord_x = ((long_x - minLong)*(892 / deltaMaxMinLong)) + 4
    coord_y = (((maxLat - lat_x)*892)/deltaMaxMinLat) + 4
    return coord_x,coord_y

# Convertion des coordonées GPS en pixels
for key in notreListePoints:
    coord = coordGpsToPixel(notreListePoints[key][0], notreListePoints[key][1])
    notreListePoints[key][0] = coord[0]
    notreListePoints[key][1] = coord[1]
    
    
# Liste d'adjacence
def listAdj(matricePoids):
    list_adj = {}
    n = len(matricePoids)
    for i in range(n):
        list_adj[nom_sommet(i)] = []
        for j in range(n):
            if (matricePoids[i][j] != 0) & (matricePoids[i][j] != float('inf')):
                list_adj[nom_sommet(i)].append(nom_sommet(j))
    return list_adj            

notreListeAdjacence = listAdj(notreMatricePoids)


"""
Création des éléments graphiques ------------------------------------------------------------------------- 
"""
def creationLignesArcs(list_adj, liste_point):
    # Permet de créer un tableau de lignes 
    # représentant les arcs du graph
    lignesArcs = []
    n = len(list_adj)
    for key in list_adj:
        point1 = Point(liste_point[key][0]+4,liste_point[key][1]+4)
        for i in range(len(list_adj[key])):
            point2 = Point(liste_point[list_adj[key][i]][0]+4,
                           liste_point[list_adj[key][i]][1]+4)
            lignesArcs.append(Line(point1,point2))
    return lignesArcs        

def creationSymbolesPoints(list_point, som_dep, som_arr):
    # Permet de créer des symboles graphiques
    # représentant le point de départ et arrivée
    symbolesPoints = []
    pointDep1 = Circle(Point(list_point[som_dep][0],list_point[som_dep][1]),10)
    pointDep1.setFill("grey")
    symbolesPoints.append(pointDep1)
    pointDep2 = Circle(Point(list_point[som_dep][0],list_point[som_dep][1]),4)
    pointDep2.setFill("white")
    pointDep2.setOutline("red")
    pointDep2.setWidth(3)
    symbolesPoints.append(pointDep2)
    
    pointArr = Circle(Point(list_point[som_arr][0],list_point[som_arr][1]),4)
    pointArr.setFill("white")
    pointArr.setOutline("red")
    pointArr.setWidth(3)
    symbolesPoints.append(pointArr)
    
    c1 = list_point[som_arr][0]
    c2 = list_point[som_arr][1]-18
    pointSymbole = Circle(Point(c1,c2),10)
    pointSymbole.setFill("grey")
    pointSymbole1 = Polygon(Point(c1-10,c2+4),Point(c1+10,c2+4),Point(c1,c2+18))
    pointSymbole1.setFill("grey")
    symbolesPoints.append(pointSymbole1)
    symbolesPoints.append(pointSymbole)
    return symbolesPoints

def creationPoints(list_point):
    # Permet de créer une liste de points
    # représentant les sommets du graph
    listePoints = []
    for key in list_point:
        listePoints.append(Circle(Point(list_point[key][0]+4,list_point[key][1]+4),2))
    return listePoints

def creationLignesChemin(chemin, list_point):
    # Permet de créer les lignes qui constitueront le 
    # tracé du chemin.
    lignesChemin = []
    for i in range(len(chemin[0])-1):
        point1 = Point(list_point[chemin[0][i]][0],list_point[chemin[0][i]][1])
        point2 = Point(list_point[chemin[0][i+1]][0],list_point[chemin[0][i+1]][1])
        line = Line(point1, point2)
        line.setFill("red")
        line.setWidth(3)
        lignesChemin.append(line)
    return lignesChemin
    

"""
Dessin éléments graphiques -------------------------------------------------------------------------------
""" 
def dessinerElementsGraphiques(window, list_elm, tempo = 0):
    # Permet de dessiner les éléments graphiques
    # de "list_elm" dans la fenêtre "window" avec
    # en option une temporisation entre chaque dessin
    for elm in list_elm:
        elm.draw(window)
        time.sleep(tempo)
    return 0
    
def effacerElementsGraphiques(list_elm):
    # Permet d'éffacer les éléments graphiques
    # de list_elm
    for elm in list_elm:
        elm.undraw()
    return 0
 
    
"""
Menu de saisi des sommets ----------------------------------------------------------------------------------------------------------------- 
"""
def menuSaisi(win):
    # Elements graphiques du menu de saisi
    interfaceElements = {'encadrementMenu':Rectangle(Point(70,50),Point(210,200)),
                         'encadrementBtn':Rectangle(Point(120,170), Point(200,190)),
                         'input1':Entry(Point(170,90),5),
                         'input2':Entry(Point(170,110),5),
                         'label1':Text(Point(120,70),"Chemin - "),
                         'label2':Text(Point(120,90),"De : "),
                         'label3':Text(Point(120,110),"Vers : "),
                         'label4':Text(Point(120,130),"min: S_1"),
                         'label5':Text(Point(120,150),"max: S_1766"),
                         'label6':Text(Point(150,180),"Valider")}
    
    interfaceElements['encadrementMenu'].setFill("white")
    interfaceElements['encadrementBtn'].setFill("green")
    # Dessin des éléments graphiques
    for elm in interfaceElements:
        interfaceElements[elm].draw(win)
    # Coordonnées coin supérieur gauche bouton et
    # coordonnées coin inférieur droite bouton
    x1 = 120
    x2 = 200
    y1 = 170
    y2 = 190
    # Récupération position du click de l'utilisateur 
    while True:
        clickPoint = win.getMouse()
        clickPointX = clickPoint.getX()
        clickPointY = clickPoint.getY()
        if ((clickPointX >= x1)&(clickPointX <= x2)) & ((clickPointY >= y1)&(clickPointY <= y2)):
            break;
    # Enregistrement des valeurs saisies par l'utilisateur    
    som_dep = interfaceElements['input1'].getText()
    som_arr = interfaceElements['input2'].getText()
    
    # Effacement des éléments graphiques
    for elm in interfaceElements:
        interfaceElements[elm].undraw()
    
    interfaceElements['input1'].setText("")
    interfaceElements['input2'].setText("")
    
    return som_dep,som_arr


"""
Application principale -------------------------------------------------------------------------------------------------------------------- 
"""
def app(list_adj, list_point, poids):
    img = Image(Point(450,450),"carte.gif")
    
    win = GraphWin("Sae 2.02 Etape 3", 900,900)
    img.draw(win)
    
    # Dessin des points (sommets) du graph
    listePoints = creationPoints(list_point)
    dessinerElementsGraphiques(win, listePoints)
    
    # Dessin des lignes (arcs) du graph
    lignesArcs = creationLignesArcs(list_adj, list_point)
    dessinerElementsGraphiques(win, lignesArcs)
    time.sleep(0.1)
    
    # Affichage du menu et récupération des sommets choisis
    choix = menuSaisi(win)
    
    # Affichage du message résumant les choix de l'utilisateur
    sousTitre = Text(Point(120,10),"chemin de " + choix[0] + " à "+choix[1])
    sousTitre.draw(win)
    
    # Dessin des symboles représentant le point de départ
    # et le point d'arrivée du chemin
    symboles = creationSymbolesPoints(list_point, choix[0], choix[1])
    dessinerElementsGraphiques(win, symboles)
    
    # Calcul du chemin le plus court
    chemin = aStar(win, list_point, poids, choix[0], choix[1])
    
    # Dessin des lignes composant le plus court chemin
    lignesChemin = creationLignesChemin(chemin, list_point)
    dessinerElementsGraphiques(win, lignesChemin, 0.03)
    
    #time.sleep(4)
    
    #effacerElementsGraphiques(symboles)
    #effacerElementsGraphiques(lignesChemin)
    
    """
    while True:
        clickPoint = win.getMouse()
        clickPointX = clickPoint.getX()
        clickPointY = clickPoint.getY()
        if ((clickPointX < x1)&(clickPointX > x2)) & ((clickPointY < y1)&(clickPointY > y2)):
            break;
        else:
            # Affichage du menu et récupération des sommets choisis
            choix = menuSaisi(win)
            
            # Affichage du message résumant les choix de l'utilisateur
            sousTitre = Text(Point(120,10),"chemin de " + choix[0] + " à "+choix[1])
            sousTitre.draw(win)
            
            # Dessin des symboles représentant le point de départ
            # et le point d'arrivée du chemin
            symboles = creationSymbolesPoints(list_point, choix[0], choix[1])
            dessinerElementsGraphiques(win, symboles)
            
            # Calcul du chemin le plus court
            chemin = aStar(poids, choix[0], choix[1])
            
            # Dessin des lignes composant le plus court chemin
            lignesChemin = creationLignesChemin(chemin, list_point)
            dessinerElementsGraphiques(win, lignesChemin, 0.03)
            
            time.sleep(4)
            
            effacerElementsGraphiques(symboles)
            effacerElementsGraphiques(lignesChemin)
     """   
                
    
    # Marche : 4km/h
    # Trail : 7km/h

    win.getMouse()
    win.close()
    

        

app(notreListeAdjacence,notreListePoints,notreMatricePoids)






