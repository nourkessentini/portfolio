#ifndef JOUER_PARTIE_H
#define JOUER_PARTIE_H
#include "InitialiserPartie.h"
#include <iostream>
using namespace std;

void afficherGrilleTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES);
// But : Afficher grilleTaquin composée de NB_LIGNES et de NB_COLONNES
 
void afficherSolution(string retenuMouvement);
// But : Afficher la solution de la partie

bool verifierSaisie(int grilleTaquin[NB_LIGNES][NB_COLONNES], string depSouhaite, string valeurADeplacer, bool joueurAbandon, short int x, short int y);
// But : Vérifier qu'une saisie est valide

bool bougerPieceTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], string depSouhaite, short int x, short int y);
// But : Déplacer une pièce de grilleTaquin selon depSouhaite

int chercherPositionX(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES, int valeurADeplacer, short int x, short int y);
// But : Retourne x en cherchant la position de valeurADeplacer dans grilleTaquin

int chercherPositionY(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES, int valeurADeplacer, short int x, short int y);
// But : Retourne y en cherchant la position de valeurADeplacer dans grilleTaquin

bool grilleEstTrie(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES);
// But : Retourne true si la grilleTaquin est triée

bool partieEstTerminee(int grilleTaquin[NB_LIGNES][NB_COLONNES], const unsigned short int CASE_VIDE, bool joueurAbandon);
// But : partieTerminee reçoit la valeur true lorsque que CASE_VIDE est dans un coin de grilleTaquin et que grilleTaquin est trié

bool joueurAbandonner(string depSouhaite, bool joueurAbandon);
// But : joueurAbandon reçoit la valeur true si le joueur a rentré “a” dans le terminal pour abandonner la partie.

#endif