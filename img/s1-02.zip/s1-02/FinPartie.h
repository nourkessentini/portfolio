#ifndef FIN_PARTIE_H
#define FIN_PARTIE_H

void afficherFinPartie(bool joueurAbandon);
// But : Afficher si le joueur a gagné en ayant terminé le jeu ou perdu par abandon à la fin de la partie.

#endif