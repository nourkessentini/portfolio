#include "FinPartie.h"
#include "game-tools.h"
#include <iostream>
using namespace std;

void afficherFinPartie(bool joueurAbandon)
{
    if(joueurAbandon == true)
    {
        afficherTexteEnCouleur("Vous avez perdu :-(", rouge, false);
    }
    else
    {
        afficherTexteEnCouleur("Felicitations, vous gagnez la partie !", vert, false);
    }
}


 