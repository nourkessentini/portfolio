#ifndef INITIALISER_PARTIE_H
#define INITIALISER_PARTIE_H
#include <iostream>
#include <string>
using namespace std;

const unsigned int NB_LIGNES = 4;// nombre de lignes de la grille
const unsigned int NB_COLONNES = 4;// nombre de colonnes de la grille

bool modeDebug();
// But : modeDebugActive reçoit true si l'utilisateur active le mode debug sinon false

void creerGrilleTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES);
// But : Créer une grille de jeu du Taquin a partir de NB_LIGNES et de NB_COLONNES

void melangerGrille(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES, string &retenuMouvements);
// But : Mélanger la grille de jeu du Taquin à partir de NB_LIGNES et de NB_COLONNES
#endif