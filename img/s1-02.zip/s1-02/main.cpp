#include "InitialiserPartie.h"
#include "JouerPartie.h"
#include "FinPartie.h"
#include "game-tools.h"
#include <iostream>
using namespace std;

int main(void)
{
    // VARIABLES
    int grilleTaquin[NB_LIGNES][NB_COLONNES]; // la grille qui présente les nombres à ordonner
    const unsigned short int CASE_VIDE = 0; // Représente la case vide de la grille du taquin
    bool modeDebugActive; // indique si l’on active le mode debug ou pas
    bool partieTerminee; //indique si la partie est terminée (la case vide est dans un coin et la grille est triée)
    bool joueurAbandon = false; // indique si le joueur décide d’abandonner.
    short int x;  
    short int y;
    string depSouhaite; //le mouvement que l'utilisateur souhaite effectuer
    string param; // Les coordonées sélectionnées pour le déplacement
    string valeurADeplacer;
    string retenuMouvements; // chaine de caractères qui retient les mouvements

    modeDebugActive = modeDebug();
    creerGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
    melangerGrille(grilleTaquin, NB_LIGNES, NB_COLONNES, retenuMouvements);
    while(true)
    {
        afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
        if(modeDebugActive == true)
        {
            afficherSolution(retenuMouvements);
        }
        while(true)
        {
            cout << "Quel mouvement souhaitez-vous faire ? (a pour abandonner) ";
            cin >> depSouhaite;
            joueurAbandon = joueurAbandonner(depSouhaite, joueurAbandon);
            if(verifierSaisie(grilleTaquin,depSouhaite,valeurADeplacer, joueurAbandon, x, y) || joueurAbandon == true)
            {
                break;
            }
        }

        partieTerminee = partieEstTerminee(grilleTaquin, CASE_VIDE, joueurAbandon);
        if(partieTerminee == true)
        {
            effacer();
            afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
            cout << "Quel mouvement souhaitez-vous faire ? (a pour abandonner) " << depSouhaite << endl;
            break;
        }
        effacer();
        
    }
    afficherFinPartie(joueurAbandon);
    return 0;
}

