#include "JouerPartie.h"
#include "InitialiserPartie.h"
#include "game-tools.h"
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

void afficherGrilleTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES)
{
    afficherTexteEnCouleur("- Jeu Du Taquin - ", bleu, true);
    for (unsigned short int i = 0; i < NB_LIGNES; i++)
    {
        for (unsigned short int j = 0; j < NB_COLONNES; j++)
        {
            if(grilleTaquin[i][j] == 0)
            {
                cout << "     ";
            }
            else
            {
                if(grilleTaquin[i][j] < 10)
                {
                    cout << "0" << grilleTaquin[i][j] << "   ";
                }
                else
                {
                    cout << grilleTaquin[i][j] << "   ";
                }
            }   
        }
        cout << endl;
    }
    cout << endl << endl;
}

 
void afficherSolution(string retenuMouvement)
{
    // Inverser le contenu de retenuMouvement
    reverse(retenuMouvement.begin(), retenuMouvement.end());
    // Afficher la solution
    afficherTexteEnCouleur("Solution : ", vert, false);
    afficherTexteEnCouleur(retenuMouvement, vert, true);
}

int chercherPositionX(int grilleTaquin[NB_LIGNES][NB_COLONNES], const unsigned int NB_LIGNES, const unsigned int NB_COLONNES, int caseAdeplacer, short int x, short int y)
{
    for (unsigned short int i = 0; i < NB_LIGNES; i++)
    {
        for (unsigned short int j = 0; j < NB_COLONNES; j++)
        {
            if(grilleTaquin[i][j] == caseAdeplacer)
            {
                x = i;
                return x;
            }
        }
    }
}

int chercherPositionY(int grilleTaquin[NB_LIGNES][NB_COLONNES], const unsigned int NB_LIGNES, const unsigned int NB_COLONNES, int caseAdeplacer, short int x, short int y)
{
    for (unsigned short int i = 0; i < NB_LIGNES; i++)
    {
        for (unsigned short int j = 0; j < NB_COLONNES; j++)
        {
            if(grilleTaquin[i][j] == caseAdeplacer)
            {
                y = j;
                return y;  
            }
        }
    }
}

bool verifierSaisie(int grilleTaquin[NB_LIGNES][NB_COLONNES], string depSouhaite, string valeurADeplacer, bool joueurAbandon, short int x, short int y)
{
    // Variables
    int valeurADep;

    // TRAITEMENTS
    if(depSouhaite == "a")
    {
        return true;
    }
    else
    {
        // Trouver la valeur a déplacer
        valeurADeplacer = depSouhaite[0];
        valeurADeplacer += depSouhaite[1];
        valeurADep = stoi(valeurADeplacer);
        // Vérifier que la valeur existe dans la grille
        if(valeurADep >= 0 && valeurADep <= NB_LIGNES * NB_COLONNES - 1)
        {
            x = chercherPositionX(grilleTaquin, NB_LIGNES, NB_COLONNES, valeurADep, x, y);
            y = chercherPositionY(grilleTaquin, NB_LIGNES, NB_COLONNES, valeurADep, x, y);
            bougerPieceTaquin(grilleTaquin, depSouhaite, x, y);
            return true;
        }
        else
        {
            cout << endl;
            afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
            pause(3);
            effacer();
            afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
        }
    }
}

bool bougerPieceTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], string depSouhaite, short int x, short int y)
{
    // VARIABLES
    string mouvementAFaire;

    //TRAITEMENTS
    // extraire le déplacement
    mouvementAFaire = depSouhaite[2];
    // Vérifier que le déplacement est valide
    if(mouvementAFaire == "h" || mouvementAFaire == "b" || mouvementAFaire == "g" || mouvementAFaire == "d")
    {
        // Déplacer la pièce
        // Déplacer la pièce vers le haut
        if(mouvementAFaire == "h")
        {
            // Déplacer la pièce vers le haut
            if(x-1 >= 0)
            {
                if(grilleTaquin[x-1][y] == 0)
                {
                    grilleTaquin[x-1][y] = grilleTaquin[x][y];
                    grilleTaquin[x][y] = 0;
                    return true;
                }
                else
                {
                    cout << endl;
                    afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                    pause(3);
                    effacer();
                    afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                    return false;
                }
            }
            else
            {
                cout << endl;
                afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                pause(3);
                effacer();
                afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                return false;
            }

        }
        // Déplacer la pièce vers le bas
        else if(mouvementAFaire == "b")
        {
            // Déplacer la pièce vers le bas
            if(x+1 >= 0)
            {
                if(grilleTaquin[x+1][y] == 0)
                {
                    grilleTaquin[x+1][y] = grilleTaquin[x][y];
                    grilleTaquin[x][y] = 0;
                    return true;
                }
                else
                {
                    cout << endl;
                    afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                    pause(3);
                    effacer();
                    afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                    return false;
                }
            }
            else
            {
                cout << endl;
                afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                pause(3);
                effacer();
                afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                return false;
            }
        }
        // Déplacer la pièce vers la gauche
        else if(mouvementAFaire == "g")
        {
            // Déplacer la pièce vers la gauche
            if(y-1 >= 0)
            {
                if(grilleTaquin[x][y-1] == 0)
                {
                    grilleTaquin[x][y-1] = grilleTaquin[x][y];
                    grilleTaquin[x][y] = 0;
                    return true;
                }
                else
                {
                    cout << endl;
                    afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                    pause(3);
                    effacer();
                    afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                    return false;
                }
            }
            else
            {
                cout << endl;
                afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                pause(3);
                effacer();
                afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                return false;
            }
        }
        // Déplacer la pièce vers la droite
        else if(mouvementAFaire == "d")
        {
            // Déplacer la pièce vers la droite
            if(y+1 >= 0)
            {
                if(grilleTaquin[x][y+1] == 0)
                {
                    grilleTaquin[x][y+1] = grilleTaquin[x][y];
                    grilleTaquin[x][y] = 0;
                    return true;
                }
                else
                {
                    cout << endl;
                    afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                    pause(3);
                    effacer();
                    afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                    return false;
                }
            }
            else
            {
                cout << endl;
                afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
                pause(3);
                effacer();
                afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
                return false;
            }
        }
    }
    else
    {
        cout << endl;
        afficherTexteEnCouleur("Mouvement invalide :-(", rouge, false);
        pause(3);
        effacer();
        afficherGrilleTaquin(grilleTaquin, NB_LIGNES, NB_COLONNES);
        return false;
    }
}

bool grilleEstTrie(int grilleTaquin[NB_LIGNES][NB_COLONNES], int NB_LIGNES, int NB_COLONNES)
{
    int compteur = 0;
    for(int i = 0; i < NB_LIGNES; i++)
    {
        for(int j = 0; j < NB_COLONNES; j++)
        {
            if(grilleTaquin[i][j] != compteur)
            {
                return false;
            }
            compteur++;
        }
    }
    return true;
}

bool partieEstTerminee(int grilleTaquin[NB_LIGNES][NB_COLONNES], const unsigned short int CASE_VIDE, bool joueurAbandon)
// Terminer la partie quand la grille est triée et que la case vide est dans un des coins
{
    // Vérifier si le joueur a abandonné la partie
    if(joueurAbandon == true)
    {
        return true;
    }

    // Vérifier si la case vide est dans un des coins
    if(grilleTaquin[0][0] == CASE_VIDE || grilleTaquin[0][NB_COLONNES-1] == CASE_VIDE || grilleTaquin[NB_LIGNES-1][0] == CASE_VIDE || grilleTaquin[NB_LIGNES-1][NB_COLONNES-1] == CASE_VIDE)
    {
        // Vérifier si la grille est triée
        if(grilleEstTrie(grilleTaquin, NB_LIGNES, NB_COLONNES) == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

bool joueurAbandonner(string depSouhaite, bool joueurAbandon)
{
    // Vérifier la réponse
    if(depSouhaite == "a")
    {
        joueurAbandon = true;
    }
    return joueurAbandon;
}







