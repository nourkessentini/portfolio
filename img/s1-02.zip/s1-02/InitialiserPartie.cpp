#include "InitialiserPartie.h"
#include "JouerPartie.h"
#include "game-tools.h"
#include <iostream>
using namespace std;

bool modeDebug()
{
    // Variables
    string reponseModeDebug;
    string REPONSE_POSITIVE = "o";
    string REPONSE_NEGATIVE = "n";

    // TRAITEMENTS

    // Saisie-Verif
    while(true)
    {
        afficherTexteEnCouleur("- Jeu Du Taquin - ", bleu, true);
        cout << endl << "Voulez-vous activer le mode debug ? (o/n) ";
        cin >> reponseModeDebug;
        if(reponseModeDebug == REPONSE_POSITIVE || reponseModeDebug == REPONSE_NEGATIVE)
        {
            effacer();
            break;
        }
        else
        {
            cout << endl;
            afficherTexteEnCouleur("Saisie incorrecte. Recommencez...", rouge, false);
            pause(3);
            effacer();
        }
    }

    // Retourner mode debug à l'état vrai ou faux selon la réponse
    if(reponseModeDebug == REPONSE_POSITIVE)
    {
        return true;
    }
    else
    {
        if(reponseModeDebug == REPONSE_NEGATIVE)
        {
            return false;
        }
    }
}

void creerGrilleTaquin(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES)
{
    // Variables
    int prochainNombre = 0;

    // TRAITEMENTS
    for(int i = 0; i < NB_LIGNES; i++)
    {
        for(int j = 0; j < NB_COLONNES; j++)
        {
            grilleTaquin[i][j] = prochainNombre;
            prochainNombre++;
        }
    }
}

void melangerGrille(int grilleTaquin[NB_LIGNES][NB_COLONNES], const int NB_LIGNES, const int NB_COLONNES, string &retenuMouvements)
// mélanger la grille et retenir le mélange dans une chaine de caractères
{
    // Variables
    int iCaseVide = 0;
    int jCaseVide = 0;
    int iCaseChoisie = 0;
    int jCaseChoisie = 0;
    int valeurCaseChoisie = 0;
    bool caseChoisieValide = false;

    // TRAITEMENTS
    for(int i = 0; i < random(15,50); i++)
    {
        // Trouver la case vide
        for(int i = 0; i < NB_LIGNES; i++)
        {
            for(int j = 0; j < NB_COLONNES; j++)
            {
                if(grilleTaquin[i][j] == 0)
                {
                    iCaseVide = i;
                    jCaseVide = j;
                }
            }
        }

        // Choisir une case à coté de la case vide
        while(!caseChoisieValide)
        {
            iCaseChoisie = iCaseVide;
            jCaseChoisie = jCaseVide;

            switch (random(1,4))
            {
                case 1:
                    jCaseChoisie++;
                    break;
                case 2:
                    iCaseChoisie++;
                    break;
                case 3:
                    jCaseChoisie--;
                    break;
                case 4:
                    iCaseChoisie--;
                    break;
            }

            // Vérifier si la case choisie est valide
            if(iCaseChoisie >= 0 && iCaseChoisie < NB_LIGNES && jCaseChoisie >= 0 && jCaseChoisie < NB_COLONNES)
            {
                caseChoisieValide = true;
            }
        }

        // Echanger les valeurs des cases
        valeurCaseChoisie = grilleTaquin[iCaseChoisie][jCaseChoisie];
        grilleTaquin[iCaseChoisie][jCaseChoisie] = grilleTaquin[iCaseVide][jCaseVide];
        grilleTaquin[iCaseVide][jCaseVide] = valeurCaseChoisie;

        // Remettre la case choisie à invalide pour la prochaine itération
        caseChoisieValide = false;
        

        //retenir le mouvement dans la chaine de caractères (vertical, horizontal)
        if(iCaseChoisie < iCaseVide)
        {
            retenuMouvements += " h";
            retenuMouvements += to_string(valeurCaseChoisie);
            if(valeurCaseChoisie < 10)
            {
                retenuMouvements += "0";
            }
        }
        else
        {
            if(iCaseChoisie > iCaseVide)
            {
                retenuMouvements += " b";
                retenuMouvements += to_string(valeurCaseChoisie);
                if(valeurCaseChoisie < 10)
                {
                    retenuMouvements += "0";
                }
            }
            else
            {
                if(jCaseChoisie < jCaseVide)
                {
                    retenuMouvements += " g";
                    retenuMouvements += to_string(valeurCaseChoisie);
                    if(valeurCaseChoisie < 10)
                    {
                        retenuMouvements += "0";
                    }
                }
                else
                {
                    if(jCaseChoisie > jCaseVide)
                    {
                        retenuMouvements += " d";
                        retenuMouvements += to_string(valeurCaseChoisie);
                        if(valeurCaseChoisie < 10)
                        {
                            retenuMouvements += "0";
                        }
                    }
                }
            }
        }
    }
}



