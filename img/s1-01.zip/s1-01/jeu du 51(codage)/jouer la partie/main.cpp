//initialiser la partie
int (void)
{
//variables
int NB_MANCHES;//le nombre de manches
int face_tirée;//la face tiréé par un joueur
int score;//le score du joueur



//affichage score initiale

return 0;
}