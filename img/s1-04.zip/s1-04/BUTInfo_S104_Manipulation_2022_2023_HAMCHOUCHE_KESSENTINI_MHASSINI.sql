--peuplement de la table TRANCHE
INSERT INTO TRANCHE (code, revenuPlancher, revenuPlafond)
VALUES
(1, 0,6000);


INSERT INTO TRANCHE (code, revenuPlancher, revenuPlafond)
VALUES
(2, 6001, 12000);

 INSERT INTO TRANCHE (code, revenuPlancher, revenuPlafond)
VALUES
(3, 12001, 18000);

INSERT INTO TRANCHE (code, revenuPlancher, revenuPlafond)
VALUES
(4, 180001, 240000);

INSERT INTO TRANCHE (code, revenuPlancher, revenuPlafond)
VALUES
(5, 24000, 100000000000);

--Peuplement de la table FAMILLE
INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(1,'DUPOND','LEO',52,'CHEMIN foret','etage premier',64100,'Bayonne',0658965265,2,4);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(2,'RENARD','AMEL',9,'avenue du lac','NO',33100,'Cenon',0658942265,3,1);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(3,'ENAJI','DYLAN',5,'residence de la fontaine','porte10',65320,'Borderes sur lEchez',0658965265,3,1);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(4,'ARICHE','LEA',6,'impasse montaury','NO',33100,'Cenon',079584665,1,3);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(5,'LOUERO','LAURA',1,'rue poullac','etage second',33000,'Bordeaux',0658965265,6,3);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(6,'AMIK','ASSIA',16,'avenue dunord','etage premier',64100,'Bayonne',0658965265,2,2);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(7,'MIHI','Lisa',16,'rue paix','NO',64100,'Bayonne',0628989265,2,5);

INSERT INTO FAMILLE(code,nomChef,prenomChef,numRue,nomRue,compAdr,codePost,ville,tel,nbEnfants,codeTranche)
VALUES(8,'PESAC','Louis',45,'rue du pont','NO',33100,'Cenon',0655978265,1,4);

--Peuplement de la table PRESTATION 
INSERT INTO PRESTATION(code,libelle)
VALUES(1 ,'cantine');

INSERT INTO PRESTATION(code,libelle)
VALUES(2,'creche');

INSERT INTO PRESTATION(code,libelle)
VALUES(3,'garderie');

--1)
SELECT AGENTDESERVICE.NOM, AGENTDESERVICE.PRENOM, ECOLE.NOM  AS ECOLEAGENT
FROM ECOLE, AGENTDESERVICE
WHERE ECOLE.CODE = AGENTDESERVICE.CODEECOLE ;

--2)
SELECT ENFANT.NOM ,ENFANT.PRENOM , PRESTATION.LIBELLE AS INSCRIPTIONPRESTATION
FROM ENFANT , PRESTATION , INSCRIRE
WHERE INSCRIRE.CODEENFANT = ENFANT.CODE
AND PRESTATION.CODE = INSCRIRE.CODEPRESTATION;

--3)
SELECT  NOM, PRENOM, ADRESSE, DATENAISS, TEL
FROM AGENTDESERVICE
ORDER BY NOM ASC ;
            
            
--4)
SELECT NBENFANTS, NOMCHEF
FROM FAMILLE
ORDER BY NBENFANTS DESC ;

--5)
SELECT COUNT( ENFANT.CODE )AS NB_ENFANT_PAR_ECOLE ,ECOLE.NOM 
FROM  ENFANT JOIN ECOLE ON ENFANT.CODEECOLE= ECOLE.CODE
GROUP BY ECOLE.NOM;


--6)
SELECT R.code ,COUNT(E.code) AS NB_TOTAL_ECOLES
 FROM RESTAURANT R JOIN ECOLE E ON R.code=E.code restau
 GROUP BY.code;
 
 
 
--7)
SELECT P.libelle COUNT(I.codePrestation) AS NB_INSCRIPTIONS
FROM INSCRIRE I
JOIN PRESTATION P ON
I.codePrestation = P.code
GROUP BY P.libelle;


--8)
SELECT  A.MATRICULE , MAX(nbHEntre)
FROM AGENTDESERVICE A
GROUP BY A.MATRICULE
HAVING MAX(NBHENTRE) >10;


--9)
SELECT F.NOMCHEF, SUM(P.tarif) AS total_prestation
FROM FAMILLE F JOIN PAYER P ON 
F.CODETRANCHE = P.CODETRANCHE
GROUP BY F.NOMCHEF
HAVING SUM(P.tarif) > (SELECT AVG(tarif)
                       FROM PAYER);
                       
                       
                       
--10)
SELECT CODEPRESTATION, MAX(TARIF)
FROM PAYER
GROUP BY CODEPRESTATION
HAVING MAX(TARIF) < 100 ;




--11)
SELECT ECOLE.NOM 
FROM ECOLE
WHERE ECOLE.CODE IN (SELECT CODEECOLE
                     FROM ENFANT
                     WHERE ENFANT.CODEECOLE = 6);
                     
                     
                     
--12)
SELECT COUNT(CODE) AS NB_RESTAURANTS_PLANIFIER
FROM RESTAURANT R
WHERE R.CODE IN (SELECT CODERESTAURANT
                                   FROM PLANIFIER
                                   WHERE PLANIFER.DATEPLANIF<='31/12/2022');
                                   
                                   
--13)
SELECT P.code
FROM PRESTATION P
WHERE P.CODE IN (SELECT CODEPRESTATION
                 FROM PAYER
                 WHERE TARIF=100); 
                 
                 
                 
--14)
SELECT E.NOM
FROM ENFANT E 
WHERE E.CODE In (SELECT CODEENFANT E 
                 FROM INSCRIRE 
                 WHERE DATEINSCRIP>='01/11/2022');