CREATE TABLE TRANCHE (
code NUMBER(3) PRIMARY KEY, 
revenuPlancher Number (6) NOT NULL, 
revenuPlafond Number (6) NOT NULL);
commit;
CREATE TABLE PRESTATION (
code NUMBER(3) PRIMARY KEY,
libelle VARCHAR2(50) NOT NULL);
commit;
CREATE TABLE FAMILLE (
code NUMBER(4) PRIMARY KEY, 
nomChef VARCHAR2(30) NOT NULL,
prenomChef VARCHAR2(40) NOT NULL,
numRue NUMBER (3),
nomRue VARCHAR2(40),
compAdr VARCHAR2(40),
codePost NUMBER(5) NOT NULL,
ville VARCHAR2(30) NOT NULL,
tel VARCHAR2(15),
nbEnfants NUMBER(2) NOT NULL,
codeTranche NUMBER(3),
FOREIGN KEY (codeTranche) REFERENCES TRANCHE(code)
);
commit;
CREATE TABLE RESTAURANT (
code NUMBER(3) PRIMARY KEY, 
nom VARCHAR2(30) NOT NULL, 
tel VARCHAR2 (15), 
effectifMax NUMBER(4) NOT NULL, 
typeLiaison VARCHAR2 (5) CHECK (typeLiaison IN ('CHAUD','FROID'))
);
commit;
CREATE TABLE ECOLE (
code NUMBER(3) PRIMARY KEY, 
nom VARCHAR2(30) not null, 
adresse VARCHAR2(60) not null, 
tel VARCHAR2 (15), 
codeRestau NUMBER(3),
FOREIGN KEY (codeRestau) REFERENCES RESTAURANT (code));
commit;
CREATE TABLE ENFANT (
code NUMBER(5)PRIMARY KEY,
nom VARCHAR2(30) NOT NULL,
prenom VARCHAR2(40) NOT NULL,
dateNaiss DATE NOT NULL,
particulariteAlim VARCHAR2(40),
codeFamille NUMBER(4),
codeEcole NUMBER(3),
FOREIGN KEY (codeFamille) REFERENCES FAMILLE(code),
FOREIGN KEY (codeEcole) REFERENCES ECOLE(code)
);
commit;
CREATE TABLE PAYER (
codeTranche NUMBER(3),
codePrestation NUMBER(3),
tarif Number (5,2) NOT NULL,
PRIMARY KEY (codeTranche, codePrestation),
FOREIGN KEY (codeTranche) REFERENCES TRANCHE(code),
FOREIGN KEY (codePrestation) REFERENCES PRESTATION(code)
);
commit;
CREATE TABLE INSCRIRE (
codeEnfant NUMBER(5),
codePrestation NUMBER(3),
dateInscrip DATE,
PRIMARY KEY (codeEnfant, codePrestation, dateInscrip),
FOREIGN KEY (codeEnfant) REFERENCES ENFANT(code),
FOREIGN KEY (codePrestation) REFERENCES PRESTATION(code));
commit;
CREATE TABLE AGENTDESERVICE (
matricule NUMBER(4)PRIMARY KEY,
nom VARCHAR2(30) NOT NULL,
prenom VARCHAR2(30) NOT NULL,
dateNaiss DATE NOT NULL,
adresse VARCHAR2(60) NOT NULL,
tel VARCHAR2(15),
horaireHebdo NUMBER(3) NOT NULL,
responsable VARCHAR2 (3) CHECK (responsable IN ('OUI', 'NON')),
nbHEntre NUMBER(3) NOT NULL,
nbHAcc NUMBER(3) NOT NULL,
codeEcole NUMBER(3),
codeRestau NUMBER(3),
FOREIGN KEY (codeEcole) REFERENCES ECOLE(code),
FOREIGN KEY (codeRestau) REFERENCES RESTAURANT(code));
commit;
CREATE TABLE TRAITEUR (
code NUMBER(3) PRIMARY KEY,
raisonSoc VARCHAR2(60) NOT NULL,
numRue NUMBER(3),
nomRue VARCHAR2(30),
compAdr VARCHAR2(60),
codePost VARCHAR2(10) NOT NULL,
ville VARCHAR2(30) NOT NULL,
tel VARCHAR2(15),
contact VARCHAR2(60));
commit;
CREATE TABLE PLANIFIER (
codeTraiteur NUMBER(3),
codeRestaurant NUMBER(3),
datePlanif DATE,
PRIMARY KEY (codeTraiteur, codeRestaurant, datePlanif),
FOREIGN KEY (codeTraiteur) REFERENCES TRAITEUR(code),
FOREIGN KEY (codeRestaurant) REFERENCES RESTAURANT(code));
commit;