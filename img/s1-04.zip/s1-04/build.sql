define path='C:\SAE'

@'&path/drop_all'
@'&path/creation'
@'&path/insertion'