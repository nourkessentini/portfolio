# -*- coding: utf-8 -*-
"""
Created on Fri May  5 14:28:28 2023

@author: rlaborde003
"""

import pyodbc
import matplotlib.pyplot as plt
import pandas as pd

#Connection à la bd 
conn=pyodbc.connect('DSN=BD_SAE_04')
cursor=conn.cursor()


def menu1():
    print("______________________________________________________\n")
    print("Est ce que le support utilisé a un impact sur la visite ? \n")
    print("  a. Nombre d'actions par support utilisé \n")
    print("  b. Le temps moyen en secondes d'une visite \n selon le support utilisé \n")
    print("  c. Nombre total de visites selon le support utilisé \n")
    print("q pour quitter \n")
    return input("  Veuillez saisir votre choix : \n")


def menu2():
    print("======================================================\n")
    print("     Nombre d'actions par support utilisé \n")
    print("  Quel est le support souhaité ? \n")
    print("  1. Ordinateur de bureau \n")
    print("  2. Tablette \n")
    print("  3. Portable \n")
    print("  4. Phablette \n")
    print("  5. Tv connecté \n\n")
    print("0 pour revenir au menu \n")
    choix = input("  Votre choix :")
    c_2=("select V.config_device_type, count(idaction) As NB_ACTIONS from ActionsVisites Join Visites V On ActionsVisites.Id_visit = V.Id_visit Join Actions A On ActionsVisites.Id_action=A.idaction Group by Config_device_type;")
    cursor.execute(c_2)
    res=[]
    ind=[]
    for row in cursor.fetchall():
        res.append(row[0])
        ind.append(row[1])

    plt.bar(res,ind)
    #plt.xlabel('Reference des articles')
    #plt.ylabel('Stock articles')
    #plt.title('Graphique des stocks des articles de plus de 5 euros à l\'unité')
    plt.show()
    return choix

def menu3():
    print("======================================================\n")
    print("     Le temps moyen en secondes d'une visite \n selon le support utilisé \n")
    print("  Quel est le support souhaité ? \n")
    print("  1. Ordinateur de bureau \n")
    print("  2. Tablette \n")
    print("  3. Portable \n")
    print("  4. Phablette \n")
    print("  5. Tv connecté \n\n")
    print("0 pour revenir au menu \n")
    return input("  Votre choix :")

def menu4():
    print("======================================================\n")
    print("     Nombre total de visites selon le support utilisé \n")
    print("  Quel est le support souhaité ? \n")
    print("  1. Ordinateur de bureau \n")
    print("  2. Tablette \n")
    print("  3. Portable \n")
    print("  4. Phablette \n")
    print("  5. Tv connecté \n\n")
    print("0 pour revenir au menu \n")
    choix = input("  Votre choix :")
    c_2=("select V.config_device_type, Count(V.Id_visit) As NB_visites From Visites V Group By V.config_device_type;")
    cursor.execute(c_2)
    res=[]
    ind=[]
    for row in cursor.fetchall():
        res.append(row[0])
        ind.append(row[1])

    plt.pie(ind,labels=res,startangle=90,autopct='%1.f%%',
            counterclock=False)
    plt.title('Répartition des visites selon le type de support utilisé')
    plt.axis('equal')
    plt.show()
    return choix

def app():
    choix = menu1()
    while choix != 'q':
        if choix == 'a':
            choix = menu2()
        elif choix == 'b':
            choix = menu3()
        elif choix == 'c':
            choix = menu4()
        else:
            choix = menu1()
            

app()