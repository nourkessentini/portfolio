/*
Programme : Jeu du 51
But : Jouer au jeu du 51 par un seul joueur muni d'un dé à 6 faces.
Date de dernière modif : 25/10/2022
Auteurs : M.Lohier et N.Kessentini
Remarques : Code conforme aux spécification internes données en cours
*/

#include "game-tools.h"
#include <string>
#include <iostream>

using namespace std;

int main(void)
{
    // VARIABLES
    int SCORE_CIBLE;    //Score que le joueur doit atteindre pour gagner la partie.
    int score;          //Score actuel du joueur
    int NB_MAX_MANCHES; //Nombre maximal de manches que le joueur peut avoir
    int manche;         //Affiche le numéro actuel de la manche
    int resultat;       //Permet, lors de la fin du jeu et selon le score, d’afficher du texte spécifique
    int face1;          //Face 1 du dé
    int face2;          //Face 2 du dé
    int face3;          //Face 3 du dé
    int face4;          //Face 4 du dé
    int face5;          //Face 5 du dé
    int face6;          //Face 6 du dé
    int faceTiree;      //Face tirée par le joueur après le lancer.
    int pointsPlus;     //Nombre de points gagnés après le lancer.
    char choix;         //Choix du joueur entre plusieurs options.

    //***************************************************************************************************
    //***************************************************************************************************

    // TRAITEMENTS

    // Paramétrer

    // >> Les parametres de defauts >> NB_MAX_MANCHES, manche , SCORE_CIBLE, SCORE, resultat
    NB_MAX_MANCHES = 15;
    manche = 0;
    SCORE_CIBLE = 51;
    score = 0;
    resultat = 0;
    // >> Les points pour chaque face >> face1, face2, face3, face4, face5, face6
    face1 = 1;
    face2 = 2;
    face3 = 3;
    face4 = 4;
    face5 = 5;
    face6 = 6;

    // SCORE_CIBLE, NB_MAX_MANCHES, face1, face2, face3, face4, face5, face6 >> Afficher message de bienvenu >> ecran
    cout << "JEU DU 51" << endl;
    cout << "-------------------" << endl;
    cout << endl;
    cout << "Vous jouez seul.e avec un de a 6 faces" << endl;
    cout << "Votre score en début de partie est 0. Deroulement d'une partie : elle se decompose en manches." << endl;
    cout << "Deroulement d'une manche : le lancer du de est realise par la machine." << endl;
    cout << "Les points associes a la face tiree sont ajoutes au score du joueur." << endl;
    cout << "Si le score atteint le SCORE_CIBLE defini par le jeu, la manche et la partie sont terminees, vous gagnez la partie." << endl;
    cout << "Si le score atteint est > SCORE_CIBLE defini par le jeu, la manche et la partie sont terminees, vous perdez la partie." << endl;
    cout << "Si le score atteint est < SCORE_CIBLE defini par le jeu, la manche est terminee, mais pa la partie. Vous pouvez alors :" << endl;
    cout << "- passer a la manche suivante" << endl;
    cout << "- abandonner la partie" << endl;
    cout << "De plus, des la seconde manche, vous pouvez aussi :" << endl;
    cout << "- passer a la manche suivante apres avoir enleve de votre score les points gagnes lors de la manche precedente," << endl;
    cout << "Vous pouvez arreter la partie quand vous le souhaitez. La question vous sera posee apres chaque manche." << endl;
    cout << "A la fin de la partie, vous pouvez commencer une nouvelle partie." << endl;
    cout << endl
         << endl
         << endl;
    cout << "Les valeurs actuelles du jeu sont les suivantes :" << endl;
    cout << " - SCORE_CIBLE = " << SCORE_CIBLE << " points" << endl;
    cout << " - Chaque face du de apporte au score le nombre de points indiques par le de :" << endl;
    cout << "  . Face 1 apporte " << face1 << " points" << endl;
    cout << "  . Face 2 apporte " << face2 << " points" << endl;
    cout << "  . Face 3 apporte " << face3 << " points" << endl;
    cout << "  . Face 4 apporte " << face4 << " points" << endl;
    cout << "  . Face 5 apporte " << face5 << " points" << endl;
    cout << "  . Face 6 apporte " << face6 << " points" << endl;
    cout << " - Nombre maximal de manches autorisee :  " << NB_MAX_MANCHES << endl;

    // SCORE_CIBLE, NB_MAX_MANCHES, face1, face2, face3, face4, face5, face6 >> Changement >> SCORE_CIBLE, NB_MAX_MANCHES, face1, face2, face3, face4, face5, face6
    do
    {
        cout << "Vous voulez changer quelque chose ? f(ace), m(anche), s(core) ou (r)ien ? ";
        cin >> choix;
        switch (choix)
        {
        case 'f':
            cout << "Saisie face 1 : ";
            cin >> face1;
            cout << "Saisie face 2 : ";
            cin >> face2;
            cout << "Saisie face 3 : ";
            cin >> face3;
            cout << "Saisie face 4 : ";
            cin >> face4;
            cout << "Saisie face 5 : ";
            cin >> face5;
            cout << "Saisie face 6 : ";
            cin >> face6;
            break;
        case 's':
            cout << "Saisie nouveau score cible : ";
            cin >> SCORE_CIBLE;
            break;
        case 'm':
            cout << "Saisie nouveau nombre de manches maximales : ";
            cin >> NB_MAX_MANCHES;
            break;
        }
    } while (choix != 'r');

    // effacer ecran
    effacer();

    //***************************************************************************************************
    //***************************************************************************************************

    // Jouer les parties
    do
    {
        // NB_MAX_MANCHES, manche, SCORE_CIBLE, score, resultat >> Jouer une partie >> 
        for (int i = manche; i < NB_MAX_MANCHES; i++)
        {
            // manche, score >> Initialiser la partie >> faceTiree, pointsPlus
            //***************************************************************

            // manche >> Incrementer le nombre de manche >> manche
            manche++;

            // manche >> Afficher manche >> ecran
            cout << "Manche : " << manche << endl;

            // score >> Afficher score initiale >> ecran
            cout << "Score initial : " << score << endl;

            // >> Tirer le de >> faceTiree
            faceTiree = random(1, 6);

            // faceTiree >> Afficher face tirée >> ecran
            cout << "Face tiree : " << faceTiree << endl;

            // faceTiree >> Points ajoutés >> pointsPlus
            switch (faceTiree)
            {
            case 1:
                pointsPlus = face1;
                break;
            case 2:
                pointsPlus = face2;
                break;
            case 3:
                pointsPlus = face3;
                break;
            case 4:
                pointsPlus = face4;
                break;
            case 5:
                pointsPlus = face5;
                break;
            case 6:
                pointsPlus = face6;
                break;
            }

            // pointsPlus >> Affichage de points ajoutés >> ecran
            cout << "Points gagnes : " << pointsPlus << endl;

            // score , pointsPlus >> Affichage nouveau score >> ecran
            cout << "Nouveau score : " << score + pointsPlus << endl;

            // manche, SCORE_CIBLE, score, pointsPlus >> Deroulement de la manche >> resultat
            //**********************************************************

            if (manche == 1)
            {
                cout << "Vous voulez (c)ontinuer ou (q)uitter la partie ? ";
                cin >> choix;
                switch (choix)
                {
                case 'c':
                    score += pointsPlus;
                    break;
                case 'q':
                    resultat = 1;
                    break;
                }

                // condition d'arret (abandon)
                if (resultat == 1)
                {
                    break;
                }
            }
            if (manche >= 2)
            {
                cout << "Vous voulez (a)bandonner la partie, (r)ejeter ou (g)arder les points du manche precedente ? ";
                cin >> choix;
            }
            switch (choix)
            {
            case 'a':
                resultat = 1;
                break;
            case 'r':
                break;
            case 'g':
                score += pointsPlus;
            }

            // condition d'arret (abandon)
            if (resultat == 1)
            {
                break;
            }

            // score, SCORE_CIBLE >> verification >> resultat
            if (score == SCORE_CIBLE)
            {
                resultat = 2;
            }
            if (score > SCORE_CIBLE)
            {
                resultat = 3;
            }

            // condition d'arret (gagner ou sscore cible dépassée)
            if ((resultat == 2) || (resultat == 3))
            {
                break;
            }
        }

        // resultat, manche, NB_MANCHES_MAX, score, SCORE_CIBLE >> Afficher resultat >> ecran
        //*********************************************************************
        switch (resultat)
        {
        case 0:
            // Affichage avec nombre de manches dépassés
            cout << "Le nombre de manches jouees " << manche << " a depasse le seuil autorisee " << NB_MAX_MANCHES << endl;
            break;
        case 1:
            // Affichage avec abandon
            cout << "Fin de jeu par abandon " << endl;
            break;
        case 2:
            // Affichage avec gagne
            cout << "Le joueur a gagne avec " << score << " points" << endl;
            break;
        case 3:
            // Affichage avec score cible dépassés
            cout << "Le score du joueur " << score << " a depasse le score cible" << SCORE_CIBLE << endl;
            break;
        }

        // score, manche, resultat >> reinitialiser les parametres >> score, manche, resultat
        score = 0;
        manche = 0;
        resultat = 0;

        // Encore une partie
        //***************************************************
        cout << "Vous voulez joueur une autre partie (o)ui ou (n)on ? ";
        cin >> choix;
        if (choix == 'n')
        {
            break;
        }

    } while (true);

    return 0;
}